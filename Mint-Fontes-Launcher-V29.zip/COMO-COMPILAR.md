# Código-fonte Mint V29

Requer .NET SDK 8 e acesso ao NuGet na compilação.

Na pasta extraída, execute:

```powershell
dotnet publish src-windows-v29/MintBrowser.csproj -c Release -r win-x64 --self-contained true -o publish
```

O executável ficará em publish. Para executar no Windows, também é necessário o Microsoft Edge WebView2 Runtime.

O script JavaScript já está incluído e embutido no projeto. Para regenerá-lo após editar o gerador, execute `python src-windows-v29/prepare-scripts.py`; a fonte base necessária foi incluída em src-v21.

Não há credenciais, cookies ou dados de sessão neste pacote. Nenhum teste ou benchmark foi executado nesta entrega.
