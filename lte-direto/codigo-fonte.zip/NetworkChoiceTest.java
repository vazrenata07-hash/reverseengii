import com.xsquarestudio.forcelte.NetworkChoice;
public class NetworkChoiceTest {
 static int count;
 static void check(boolean ok,String message){count++;if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
 check(NetworkChoice.score(0,"WCDMA only")==100,"3G AOSP");
 check(NetworkChoice.score(0,"UMTS only")==100,"3G alternate");
 check(NetworkChoice.score(1,"LTE only")==100,"4G AOSP");
 check(NetworkChoice.score(2,"NR/LTE")==100,"5G NSA");
 check(NetworkChoice.score(2,"NR only")==90,"5G SA");
 check(NetworkChoice.score(1,"LTE/UMTS auto (PRL)")==0,"Reject automatic mixed network");
 check(NetworkChoice.score(0,"GSM only")==0,"Do not select 2G");
 check(NetworkChoice.score(2,"LTE only")==0,"LTE is not 5G");
 check(NetworkChoice.score(1,"NR/LTE")==0,"5G mixed option is not 4G-only");
 check(NetworkChoice.score(0,null)==0,"Null text");
 check(NetworkChoice.score(2,"NR/LTE/GSM/WCDMA")==0,"No broad fallback");
 System.out.println(count+" network matching checks passed");
 }
}
