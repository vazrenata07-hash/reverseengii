package com.xsquarestudio.forcelte;
import java.util.Locale;
public final class NetworkChoice {
 public static String normalize(String s){return s==null?"":s.toUpperCase(Locale.ROOT).replaceAll("[\\s_()-]","");}
 public static int score(int generation,String text){
  String s=normalize(text);
  if(generation==0){if(s.equals("WCDMAONLY")||s.equals("UMTSONLY")||s.equals("3GONLY")||s.equals("SOMENTE3G"))return 100;return 0;}
  if(generation==1){if(s.equals("LTEONLY")||s.equals("4GONLY")||s.equals("SOMENTE4G"))return 100;return 0;}
  if(s.equals("NR/LTE"))return 100;
  if(s.equals("NR/LTEONLY"))return 95;
  if(s.equals("NRONLY")||s.equals("5GONLY")||s.equals("SOMENTE5G"))return 90;
  return 0;
 }
 public static boolean isNetworkLabel(String text){
  String s=java.text.Normalizer.normalize(text,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).trim();
  return s.startsWith("definir tipo de rede preferido")||s.startsWith("set preferred network type")||s.startsWith("tipo de rede preferido:")||s.startsWith("preferred network type:");
 }
 private NetworkChoice(){}
}
