package com.xsquarestudio.forcelte;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.app.KeyguardManager;
import android.view.*;
import android.view.accessibility.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class CycleService extends AccessibilityService {
 public static CycleService live;
 final Handler clock=new Handler(Looper.getMainLooper());
 final Handler events=new Handler(Looper.getMainLooper());
 WindowManager wm; WindowManager.LayoutParams params; LinearLayout panel,body; TextView status,header;
 EditText seconds; CheckBox[] checks=new CheckBox[3]; Button toggle,compact;
 TouchCalibration calibration;TouchCalibration.Profile touchProfile;boolean gestureMode;
 boolean running,hidden,collapsed; int cursor,epoch; long interval; int[] choices;
 final String[] names={"3G","4G","5G"}; String pendingLabel="";
 boolean requested;
 final Runnable refresh=new Runnable(){public void run(){refreshPanel();events.postDelayed(this,600);}};
 BroadcastReceiver screen=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(calibration!=null)calibration.end(false,"Calibração interrompida: tela bloqueada.");stop("Parado: tela bloqueada.");removePanel();}};
 @Override protected void onServiceConnected(){super.onServiceConnected();live=this;AccessibilityServiceInfo info=getServiceInfo();info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;setServiceInfo(info);wm=(WindowManager)getSystemService(WINDOW_SERVICE);registerReceiver(screen,new IntentFilter(Intent.ACTION_SCREEN_OFF));events.post(refresh);}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){
  if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED&&(running||calibration!=null)&&e.getPackageName()!=null){String p=e.getPackageName().toString();if(!p.equals(getPackageName())&&!p.equals("com.android.phone")&&!p.equals("com.android.settings")){if(calibration!=null)calibration.end(false,"Calibração parada ao sair da tela.");stop("Parado ao sair da tela de rede.");}}
  if(!events.hasCallbacks(refresh))events.postDelayed(refresh,100);
 }
 @Override public void onInterrupt(){stop("Serviço interrompido.");removePanel();}
 @Override public void onDestroy(){if(calibration!=null)calibration.end(false,"Serviço encerrado.");stop("Parado");events.removeCallbacksAndMessages(null);removePanel();try{unregisterReceiver(screen);}catch(Exception e){}if(live==this)live=null;super.onDestroy();}
 void reopen(){hidden=false;requested=true;if(panel==null)showPanel();events.removeCallbacks(refresh);events.postDelayed(refresh,250);}
 int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
 ArrayList<AccessibilityNodeInfo> roots(){
  ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();
  for(AccessibilityWindowInfo w:getWindows()){if(w.getType()==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY)continue;AccessibilityNodeInfo n=w.getRoot();if(allowed(n))all.add(n);}
  AccessibilityNodeInfo active=getRootInActiveWindow();if(allowed(active))all.add(0,active);
  return all;
 }
 boolean allowed(AccessibilityNodeInfo n){if(n==null||n.getPackageName()==null)return false;String p=n.getPackageName().toString();return p.equals("com.android.phone")||p.equals("com.android.settings");}
 AccessibilityNodeInfo spinner(){for(AccessibilityNodeInfo r:roots()){AccessibilityNodeInfo n=findSpinner(r,0);if(n!=null)return n;if(isRadioInfo(r,0)){n=findNetworkSpinner(r,0);if(n!=null)return n;}}return null;}
 boolean isRadioInfo(AccessibilityNodeInfo n,int depth){
  if(n==null||depth>35)return false;
  String id=n.getViewIdResourceName();
  if(id!=null&&(id.endsWith(":id/preferredNetworkType")||id.endsWith(":id/preferred_network_type")||id.endsWith(":id/radio_power")))return true;
  if(n.getText()!=null&&NetworkChoice.isNetworkLabel(n.getText().toString()))return true;
  for(int i=0;i<n.getChildCount();i++)if(isRadioInfo(n.getChild(i),depth+1))return true;
  return false;
 }
 AccessibilityNodeInfo findNetworkSpinner(AccessibilityNodeInfo n,int depth){
  if(n==null||depth>35)return null;
  String cls=String.valueOf(n.getClassName());
  if(cls.contains("Spinner")&&n.isVisibleToUser()){String text=NetworkChoice.normalize(nodeText(n));if(text.contains("LTE")||text.contains("WCDMA")||text.contains("GSM")||text.contains("UMTS")||text.contains("NR"))return n;}
  for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo hit=findNetworkSpinner(n.getChild(i),depth+1);if(hit!=null)return hit;}
  return null;
 }
 AccessibilityNodeInfo findSpinner(AccessibilityNodeInfo n,int depth){
  if(n==null||depth>35)return null;
  String id=n.getViewIdResourceName();
  if(id!=null&&(id.endsWith(":id/preferredNetworkType")||id.endsWith(":id/preferred_network_type"))&&n.isVisibleToUser())return n;
  // Prefer IDs; the separate fallback requires RadioInfo labels and a network-valued Spinner.
  for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo hit=findSpinner(n.getChild(i),depth+1);if(hit!=null)return hit;}
  return null;
 }
 boolean unlocked(){PowerManager p=(PowerManager)getSystemService(POWER_SERVICE);KeyguardManager k=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);return p.isInteractive()&&!k.isKeyguardLocked();}
 void refreshPanel(){
  if(calibration!=null)return;
  if(!unlocked()){if(running)stop("Parado: tela bloqueada.");removePanel();return;}
  boolean radio=false;for(AccessibilityNodeInfo r:roots())if(isRadioInfo(r,0)){radio=true;break;}
  if((radio||requested)&&!hidden&&panel==null)showPanel();
  // Missing accessibility nodes are not evidence that the user left RadioInfo.
  // Keep the user-requested controls visible until closed or the screen locks.

 }
 void showPanel(){
  if(panel!=null)return;
  panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(6),dp(10),dp(10));
  GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(249,251,253));bg.setCornerRadius(dp(16));bg.setStroke(dp(1),Color.rgb(0,137,123));panel.setBackground(bg);panel.setElevation(dp(8));
  LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
  header=new TextView(this);header.setText("⠿  LTE Direto");header.setTextSize(16);header.setTextColor(Color.rgb(0,105,92));bar.addView(header,new LinearLayout.LayoutParams(0,dp(42),1));
  compact=new Button(this);compact.setText("−");compact.setTextSize(18);bar.addView(compact,new LinearLayout.LayoutParams(dp(46),dp(42)));
  Button close=new Button(this);close.setText("×");bar.addView(close,new LinearLayout.LayoutParams(dp(46),dp(42)));panel.addView(bar);
  body=new LinearLayout(this);body.setOrientation(1);panel.addView(body);
  TextView label=new TextView(this);label.setText("Intervalo (segundos)");body.addView(label);
  seconds=new EditText(this);seconds.setInputType(2);seconds.setSingleLine(true);seconds.setText(getSharedPreferences("cycle",0).getString("seconds","30"));seconds.setSelectAllOnFocus(true);body.addView(seconds,new LinearLayout.LayoutParams(-1,dp(46)));
  LinearLayout row=new LinearLayout(this);
  for(int i=0;i<3;i++){checks[i]=new CheckBox(this);checks[i].setText(names[i]);checks[i].setTextSize(14);checks[i].setChecked(getSharedPreferences("cycle",0).getBoolean("n"+i,i<2));row.addView(checks[i],new LinearLayout.LayoutParams(0,dp(44),1));}body.addView(row);
  toggle=new Button(this);toggle.setText("Iniciar");body.addView(toggle);
  LinearLayout extra=new LinearLayout(this);
  Button calibrate=new Button(this);calibrate.setText("Calibrar toques");calibrate.setTextSize(12);extra.addView(calibrate,new LinearLayout.LayoutParams(0,dp(44),2));calibrate.setOnClickListener(v->calibrate());
  Button diagnostic=new Button(this);diagnostic.setText("Diagnóstico");diagnostic.setTextSize(11);extra.addView(diagnostic,new LinearLayout.LayoutParams(0,dp(44),2));diagnostic.setOnClickListener(v->message(diagnostics()));body.addView(extra);
  status=new TextView(this);status.setText("Parado • arraste o título para mover");status.setTextSize(12);body.addView(status);
  TextView note=new TextView(this);note.setText("Sem leitura do seletor? Use Calibrar toques uma vez. Depois mantenha esta tela na mesma posição. IP novo depende da operadora.");note.setTextSize(11);note.setPadding(0,dp(6),0,0);body.addView(note);
  params=new WindowManager.LayoutParams(dp(280),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,android.graphics.PixelFormat.TRANSLUCENT);
  params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(40);params.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
  try{wm.addView(panel,params);}catch(Exception e){panel=null;hidden=true;Toast.makeText(this,"Não foi possível mostrar o painel: "+e.getClass().getSimpleName()+". Desative e reative LTE Direto em Acessibilidade.",Toast.LENGTH_LONG).show();return;}
  seconds.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN&&!running){params.flags&=~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;wm.updateViewLayout(panel,params);seconds.requestFocus();}return false;});
  collapsed=false;compact.setOnClickListener(v->collapse(!collapsed));close.setOnClickListener(v->{stop("Parado");hidden=true;requested=false;removePanel();});
  toggle.setOnClickListener(v->{if(running)stop("Parado • última rede mantida");else start();});
  header.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int px,py;boolean moved;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();px=params.x;py=params.y;moved=false;return true;}if(e.getAction()==2){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>dp(6))moved=true;params.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-params.width,px+(int)dx));params.y=Math.max(dp(24),Math.min(getResources().getDisplayMetrics().heightPixels-dp(80),py+(int)dy));if(panel!=null)wm.updateViewLayout(panel,params);return true;}if(e.getAction()==1){if(!moved&&collapsed)stop("Parado • última rede mantida");return true;}return false;}});
 }
 void collapse(boolean value){collapsed=value;body.setVisibility(value?View.GONE:View.VISIBLE);compact.setText(value?"+":"−");params.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;wm.updateViewLayout(panel,params);}
 void removePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception e){}panel=null;}}
 void message(String text){if(status!=null)status.setText(text);if(header!=null)header.setText(running?"⠿  Parar • "+pendingLabel:"⠿  LTE Direto");}
 void stop(String text){running=false;epoch++;clock.removeCallbacksAndMessages(null);if(toggle!=null){toggle.setText("Iniciar");toggle.setEnabled(true);}if(seconds!=null)seconds.setEnabled(true);for(CheckBox c:checks)if(c!=null)c.setEnabled(true);if(panel!=null)collapse(collapsed);message(text);}
 void start(){
  // Release the editing window before requesting another app's node tree.
  seconds.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(seconds.getWindowToken(),0);collapse(collapsed);
  message("Localizando seletor…");toggle.setEnabled(false);
  clock.postDelayed(()->{toggle.setEnabled(true);begin(0);},350);
 }
 void begin(int attempt){
  long n;try{n=Long.parseLong(seconds.getText().toString().trim());if(n<1||n>86400)throw new NumberFormatException();}catch(Exception e){message("Intervalo: 1 a 86400 segundos.");return;}
  ArrayList<Integer> list=new ArrayList<>();for(int i=0;i<3;i++)if(checks[i].isChecked())list.add(i);if(list.size()<2){message("Marque pelo menos duas redes.");return;}
  choices=new int[list.size()];for(int i=0;i<list.size();i++)choices[i]=list.get(i);
  SharedPreferences.Editor pref=getSharedPreferences("cycle",0).edit().putString("seconds",Long.toString(n));for(int i=0;i<3;i++)pref.putBoolean("n"+i,checks[i].isChecked());pref.apply();
  touchProfile=TouchCalibration.load(this,choices);gestureMode=touchProfile!=null;
  if(!gestureMode&&spinner()==null){message("Use Calibrar toques para ensinar o seletor e as redes. Não foi possível ler a tela automaticamente.");return;}
  interval=n*1000;cursor=0;running=true;int token=++epoch;seconds.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(seconds.getWindowToken(),0);seconds.setEnabled(false);for(CheckBox c:checks)c.setEnabled(false);toggle.setText("Parar");collapse(gestureMode||collapsed);next(token);
 }
 void calibrate(){
  if(running){stop("Pare antes de calibrar.");return;}
  ArrayList<Integer> modes=new ArrayList<>();SharedPreferences.Editor prefs=getSharedPreferences("cycle",0).edit().putString("seconds",seconds.getText().toString());
  for(int i=0;i<3;i++){prefs.putBoolean("n"+i,checks[i].isChecked());if(checks[i].isChecked())modes.add(i);}prefs.apply();
  if(modes.size()<2){message("Marque pelo menos duas redes antes de calibrar.");return;}
  if((getServiceInfo().getCapabilities()&AccessibilityServiceInfo.CAPABILITY_CAN_PERFORM_GESTURES)==0){message("Desative e reative LTE Direto em Acessibilidade para permitir os gestos.");return;}
  stop("Preparando calibração…");int[] selected=new int[modes.size()];for(int i=0;i<selected.length;i++)selected[i]=modes.get(i);
  calibration=new TouchCalibration(this,selected,(ok,text)->{calibration=null;if(unlocked()&&!hidden){showPanel();message(text);}});removePanel();calibration.start();
 }
 void gesturePassThrough(boolean enabled){if(panel==null)return;if(enabled)params.flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;else params.flags&=~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;try{wm.updateViewLayout(panel,params);}catch(Exception e){}}
 String diagnostics(){
  StringBuilder b=new StringBuilder("Janelas: ").append(getWindows().size()).append("; raízes aceitas: ").append(roots().size()).append("\n");
  AccessibilityNodeInfo active=getRootInActiveWindow();b.append("Ativa: ").append(active==null?"sem acesso":String.valueOf(active.getPackageName())).append("\n");
  for(AccessibilityWindowInfo w:getWindows()){AccessibilityNodeInfo r=w.getRoot();b.append("Tipo ").append(w.getType()).append(": ").append(r==null?"sem raiz":String.valueOf(r.getPackageName())).append("\n");}
  return b.toString();
 }

 boolean valid(int token){return running&&epoch==token&&unlocked();}
 void next(int token){
  if(!valid(token)){if(running)stop("Parado: tela indisponível.");return;}
  if(gestureMode){int target=choices[cursor++%choices.length];pendingLabel=names[target];message("Enviando toques: "+names[target]+"…");TouchCalibration.play(this,touchProfile,target,()->valid(token),ok->{if(!valid(token))return;if(!ok){stop("Gesto cancelado. Recalibre se a posição da tela mudou.");return;}message("Toques enviados: "+names[target]+" • próxima em "+(interval/1000)+" s");clock.postDelayed(()->next(token),interval);});return;}
  AccessibilityNodeInfo sp=spinner();if(sp==null){stop("Parado: volte ao seletor de rede.");return;}
  int target=choices[cursor++%choices.length];pendingLabel=names[target];message("Selecionando "+names[target]+"…");
  if(!click(sp)){stop("Não foi possível abrir o seletor.");return;}
  clock.postDelayed(()->select(token,target,0,false),400);
 }
 boolean click(AccessibilityNodeInfo n){for(int i=0;n!=null&&i<4;i++,n=n.getParent())if(n.isClickable()&&n.isEnabled())return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);return false;}
 AccessibilityNodeInfo rowChoice;int rowScore;
 void scan(AccessibilityNodeInfo n,int target,boolean inList,int depth){
  if(n==null||depth>35)return;String cls=String.valueOf(n.getClassName());
  boolean list=inList||cls.contains("ListView")||cls.contains("RecyclerView");
  if(list&&n.isVisibleToUser()&&n.getText()!=null){int score=NetworkChoice.score(target,n.getText().toString());if(score>rowScore){rowScore=score;rowChoice=n;}}
  for(int i=0;i<n.getChildCount();i++)scan(n.getChild(i),target,list,depth+1);
 }
 AccessibilityNodeInfo scrollList(AccessibilityNodeInfo n,int depth){if(n==null||depth>35)return null;String c=String.valueOf(n.getClassName());if(n.isScrollable()&&(c.contains("ListView")||c.contains("RecyclerView")))return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=scrollList(n.getChild(i),depth+1);if(r!=null)return r;}return null;}
 void select(int token,int target,int tries,boolean rewound){
  if(!valid(token))return;rowChoice=null;rowScore=0;ArrayList<AccessibilityNodeInfo> windows=roots();
  for(AccessibilityNodeInfo r:windows)scan(r,target,false,0);
  if(rowChoice!=null){if(!click(rowChoice)){stop("Não foi possível selecionar "+names[target]+".");return;}clock.postDelayed(()->verify(token,target,0),500);return;}
  if(tries>=16){performGlobalAction(GLOBAL_ACTION_BACK);stop(names[target]+" indisponível ou lista incompatível.");return;}
  AccessibilityNodeInfo list=null;for(AccessibilityNodeInfo r:windows){list=scrollList(r,0);if(list!=null)break;}
  if(list==null){if(tries<3){clock.postDelayed(()->select(token,target,tries+1,rewound),300);return;}stop("Lista de redes não encontrada. Tente abrir o seletor manualmente.");return;}
  // First rewind to the beginning; then scan downward. Never tap by screen coordinates.
  if(!rewound){boolean moved=list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);final boolean reset=!moved;clock.postDelayed(()->select(token,target,tries+1,reset),180);}
  else{if(!list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){performGlobalAction(GLOBAL_ACTION_BACK);stop(names[target]+" não consta na lista. Desmarque essa rede.");return;}clock.postDelayed(()->select(token,target,tries+1,true),180);}
 }
 String nodeText(AccessibilityNodeInfo n){if(n==null)return "";StringBuilder b=new StringBuilder();if(n.getText()!=null)b.append(n.getText());for(int i=0;i<n.getChildCount();i++)b.append(nodeText(n.getChild(i)));return b.toString();}
 void verify(int token,int target,int attempt){
  if(!valid(token))return;AccessibilityNodeInfo sp=spinner();
  if(sp!=null&&NetworkChoice.score(target,nodeText(sp))>0){message("Selecionado: "+names[target]+" • próxima em "+(interval/1000)+" s");clock.postDelayed(()->next(token),interval);return;}
  if(attempt<4){clock.postDelayed(()->verify(token,target,attempt+1),350);return;}
  stop("Seleção não confirmada. Verifique a tela do Android.");
 }
}
