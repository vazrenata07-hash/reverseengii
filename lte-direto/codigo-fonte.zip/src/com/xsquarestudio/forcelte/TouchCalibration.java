package com.xsquarestudio.forcelte;

import android.accessibilityservice.GestureDescription;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** User-taught gestures; no pixel matching, phone data, or hard-coded screen coordinates. */
public final class TouchCalibration {
 public interface Result {void done(boolean ok,String message);}
 public static final class Stroke {
  final float x,y,endX,endY; final long duration;
  Stroke(float a,float b,float c,float d,long ms){x=a;y=b;endX=c;endY=d;duration=ms;}
  boolean tap(){return Math.hypot(endX-x,endY-y)<12;}
  JSONObject json()throws JSONException{return new JSONObject().put("x",x).put("y",y).put("ex",endX).put("ey",endY).put("ms",duration);}
  static Stroke from(JSONObject o)throws JSONException{return new Stroke((float)o.getDouble("x"),(float)o.getDouble("y"),(float)o.getDouble("ex"),(float)o.getDouble("ey"),o.getLong("ms"));}
 }
 public static final class Profile {
  int width,height;float selectorX,selectorY,left,top,right,bottom; JSONObject modes=new JSONObject();
  JSONObject json()throws JSONException{return new JSONObject().put("width",width).put("height",height).put("sx",selectorX).put("sy",selectorY).put("left",left).put("top",top).put("right",right).put("bottom",bottom).put("modes",modes);}
  static Profile from(String raw)throws JSONException{JSONObject o=new JSONObject(raw);Profile p=new Profile();p.width=o.getInt("width");p.height=o.getInt("height");p.selectorX=(float)o.getDouble("sx");p.selectorY=(float)o.getDouble("sy");p.left=(float)o.getDouble("left");p.top=(float)o.getDouble("top");p.right=(float)o.getDouble("right");p.bottom=(float)o.getDouble("bottom");p.modes=o.getJSONObject("modes");return p;}
 }
 final CycleService service;final Handler timer=new Handler(Looper.getMainLooper());final WindowManager wm;
 final int[] targets; final Result finish; Profile profile=new Profile(); FrameLayout layer;TextView guide;Button proceed;
 int stage,modeIndex;boolean active=true,busy;float startX,startY,boundX,boundY;long downAt;ArrayList<Stroke> recording=new ArrayList<>();
 TouchCalibration(CycleService s,int[] selected,Result result){service=s;targets=selected;finish=result;wm=s.wm;profile.width=s.getResources().getDisplayMetrics().widthPixels;profile.height=s.getResources().getDisplayMetrics().heightPixels;}
 int dp(int n){return service.dp(n);}
 void start(){
  layer=new FrameLayout(service);
  android.view.View capture=new android.view.View(service);layer.addView(capture,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout bar=new LinearLayout(service);bar.setOrientation(1);bar.setPadding(dp(10),dp(24),dp(10),dp(8));
  GradientDrawable bg=new GradientDrawable();bg.setColor(0xffe5f6f3);bg.setStroke(dp(1),0xff00897b);bar.setBackground(bg);
  guide=new TextView(service);guide.setTextColor(0xff003d35);guide.setTextSize(14);bar.addView(guide);
  LinearLayout actions=new LinearLayout(service);proceed=new Button(service);proceed.setText("Continuar");actions.addView(proceed,new LinearLayout.LayoutParams(0,dp(44),1));
  Button cancel=new Button(service);cancel.setText("Cancelar");actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(44),1));Button move=new Button(service);move.setText("Mover");actions.addView(move,new LinearLayout.LayoutParams(0,dp(44),1));move.setOnClickListener(v->{FrameLayout.LayoutParams bp=(FrameLayout.LayoutParams)bar.getLayoutParams();bp.gravity=bp.gravity==Gravity.TOP?Gravity.BOTTOM:Gravity.TOP;bar.setLayoutParams(bp);});bar.addView(actions);
  layer.addView(bar,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
  cancel.setOnClickListener(v->end(false,"Calibração cancelada."));
  proceed.setOnClickListener(v->{if(stage==0){stage=1;proceed.setVisibility(View.GONE);say("1. Toque no seletor de rede (a linha LTE/UMTS etc.).");}});
  capture.setOnTouchListener((v,e)->{
   if(busy||!active)return true;
   if(e.getAction()==MotionEvent.ACTION_DOWN){startX=e.getRawX();startY=e.getRawY();downAt=SystemClock.uptimeMillis();return true;}
   if(e.getAction()==MotionEvent.ACTION_UP){float ex=e.getRawX(),ey=e.getRawY();boolean tap=Math.hypot(ex-startX,ey-startY)<dp(12);Stroke stroke=new Stroke(startX,startY,tap?startX:ex,tap?startY:ey,tap?80:Math.max(120,Math.min(900,SystemClock.uptimeMillis()-downAt)));handle(stroke,tap);return true;}
   return true;
  });
  say("Preparar: feche a lista de redes tocando fora dela, se estiver aberta. Depois toque Continuar.");attach();
 }
 void say(String s){guide.setText(s);}
 void attach(){if(!active||layer.getParent()!=null)return;WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;try{wm.addView(layer,p);}catch(Exception e){end(false,"Não foi possível abrir a calibração.");}}
 void detach(){if(layer!=null&&layer.getParent()!=null)try{wm.removeView(layer);}catch(Exception e){}}
 void handle(Stroke stroke,boolean tap){
  if(stage==0){forward(stroke,()->{});return;}
  if(stage==1){if(!tap){say("Toque na linha que abre a lista de redes.");return;}profile.selectorX=stroke.x;profile.selectorY=stroke.y;forward(stroke,()->{stage=2;say("2. Lista aberta: toque perto do canto SUPERIOR ESQUERDO da lista. Esse toque apenas marca a área.");});return;}
  if(stage==2){boundX=stroke.x;boundY=stroke.y;stage=3;say("3. Toque perto do canto INFERIOR DIREITO da lista visível. Esse toque também só marca a área.");return;}
  if(stage==3){
   profile.left=Math.min(boundX,stroke.x);profile.right=Math.max(boundX,stroke.x);profile.top=Math.min(boundY,stroke.y);profile.bottom=Math.max(boundY,stroke.y);
   if(profile.right-profile.left<dp(70)||profile.bottom-profile.top<dp(100)){stage=2;say("Área pequena. Marque novamente o canto SUPERIOR ESQUERDO da lista.");return;}
   prepareRecording(false);return;
  }
  if(stage==4){recording.add(stroke);forward(stroke,()->{if(tap)saveMode();});}
 }
 void forward(Stroke stroke,Runnable after){busy=true;detach();timer.postDelayed(()->{if(!active)return;dispatch(service,stroke,ok->{if(!active)return;timer.postDelayed(()->{if(!active)return;busy=false;attach();if(ok)after.run();else end(false,"O Android cancelou o gesto. Tente calibrar novamente.");},250);});},100);}
 void prepareRecording(boolean open){
  busy=true;detach();String label=service.names[targets[modeIndex]];say("Preparando a lista para "+label+"…");
  Runnable reset=()->rewind(service,profile,6,()->active,ok->{if(!active)return;if(!ok){end(false,"Não foi possível rolar a lista.");return;}recording.clear();stage=4;busy=false;attach();int mode=targets[modeIndex];say("Gravar "+service.names[mode]+": role a lista e toque em "+(mode==0?"WCDMA only (ou UMTS only)":mode==1?"LTE only":"NR/LTE (ou NR only)")+". Seus gestos serão repetidos depois.");});
  timer.postDelayed(()->{if(!active)return;if(open)dispatch(service,new Stroke(profile.selectorX,profile.selectorY,profile.selectorX,profile.selectorY,80),ok->{if(active&&ok)timer.postDelayed(reset,350);else if(active)end(false,"Não foi possível abrir a lista.");});else reset.run();},200);
 }
 void saveMode(){try{JSONArray sequence=new JSONArray();for(Stroke s:recording)sequence.put(s.json());profile.modes.put(Integer.toString(targets[modeIndex]),sequence);modeIndex++;if(modeIndex<targets.length)prepareRecording(true);else{service.getSharedPreferences("cycle",0).edit().putString("touchProfile",profile.json().toString()).apply();end(true,"Calibração salva. Toque Iniciar.");}}catch(Exception e){end(false,"Falha ao salvar calibração.");}}
 void end(boolean ok,String message){if(!active)return;active=false;timer.removeCallbacksAndMessages(null);detach();finish.done(ok,message);}
 public interface Gate{boolean valid();}
 public static void dispatch(CycleService s,Stroke stroke,java.util.function.Consumer<Boolean> callback){
  Path path=new Path();path.moveTo(stroke.x,stroke.y);if(!stroke.tap())path.lineTo(stroke.endX,stroke.endY);
  GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,100,stroke.duration)).build();
  s.gesturePassThrough(true);
  try{boolean started=s.dispatchGesture(g,new android.accessibilityservice.AccessibilityService.GestureResultCallback(){public void onCompleted(GestureDescription g){s.gesturePassThrough(false);callback.accept(true);}public void onCancelled(GestureDescription g){s.gesturePassThrough(false);callback.accept(false);}},null);if(!started){s.gesturePassThrough(false);callback.accept(false);}}catch(Exception e){s.gesturePassThrough(false);callback.accept(false);}
 }
 static void rewind(CycleService s,Profile p,int remaining,Gate gate,java.util.function.Consumer<Boolean> done){
  if(!gate.valid())return;if(remaining==0){done.accept(true);return;}
  float x=(p.left+p.right)/2;float inset=Math.min(s.dp(18),(p.bottom-p.top)/6);
  dispatch(s,new Stroke(x,p.top+inset,x,p.bottom-inset,220),ok->{if(!gate.valid())return;if(!ok){done.accept(false);return;}s.clock.postDelayed(()->rewind(s,p,remaining-1,gate,done),160);});
 }
 static Profile load(CycleService s,int[] choices){try{Profile p=Profile.from(s.getSharedPreferences("cycle",0).getString("touchProfile",""));if(p.width!=s.getResources().getDisplayMetrics().widthPixels||p.height!=s.getResources().getDisplayMetrics().heightPixels)return null;for(int mode:choices)if(!p.modes.has(Integer.toString(mode)))return null;return p;}catch(Exception e){return null;}}
 static void play(CycleService s,Profile p,int mode,Gate gate,java.util.function.Consumer<Boolean> done){
  if(!gate.valid())return;
  dispatch(s,new Stroke(p.selectorX,p.selectorY,p.selectorX,p.selectorY,80),ok->{if(!gate.valid())return;if(!ok){done.accept(false);return;}s.clock.postDelayed(()->rewind(s,p,6,gate,reset->{if(!gate.valid())return;if(!reset){done.accept(false);return;}try{replay(s,p.modes.getJSONArray(Integer.toString(mode)),0,gate,done);}catch(Exception e){done.accept(false);}}),400);});
 }
 static void replay(CycleService s,JSONArray sequence,int i,Gate gate,java.util.function.Consumer<Boolean> done){
  if(!gate.valid())return;if(i==sequence.length()){done.accept(true);return;}
  try{Stroke stroke=Stroke.from(sequence.getJSONObject(i));dispatch(s,stroke,ok->{if(!gate.valid())return;if(!ok){done.accept(false);return;}s.clock.postDelayed(()->replay(s,sequence,i+1,gate,done),300);});}catch(Exception e){done.accept(false);}
 }
}
