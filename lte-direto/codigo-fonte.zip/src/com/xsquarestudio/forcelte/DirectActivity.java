package com.xsquarestudio.forcelte;

import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class DirectActivity extends Activity {
 boolean launching;
 final android.os.Handler waitForService=new android.os.Handler(android.os.Looper.getMainLooper());
 final Runnable checkService=new Runnable(){public void run(){if(CycleService.live!=null&&!launching)open();else waitForService.postDelayed(this,500);}};
 @Override public void onCreate(Bundle b) {super.onCreate(b); setup();}
 @Override public void onResume(){super.onResume();waitForService.post(checkService);}
 @Override public void onPause(){waitForService.removeCallbacks(checkService);super.onPause();}
 void setup(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(28,36,28,24);
  TextView title=new TextView(this);title.setText("LTE Direto");title.setTextSize(26);box.addView(title);
  TextView help=new TextView(this);help.setText("Ative uma vez o serviço LTE Direto em Acessibilidade. Depois, o app abre diretamente as informações do telefone com o painel flutuante.\n\nO serviço toca apenas no seletor de rede desta tela. Não grava nem envia dados. Mantenha a tela desbloqueada durante a alternância.");help.setTextSize(16);help.setPadding(0,20,0,20);box.addView(help);
  Button access=new Button(this);access.setText("Ativar Acessibilidade");access.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){Toast.makeText(this,"Abra Configurações > Acessibilidade > LTE Direto",1).show();}});box.addView(access);
  Button direct=new Button(this);direct.setText("Abrir com botão Iniciar");direct.setOnClickListener(v->{if(CycleService.live==null){new android.app.AlertDialog.Builder(this).setTitle("Ative o painel primeiro").setMessage("Para mostrar Iniciar/Parar sobre a configuração, habilite LTE Direto em Configurações > Acessibilidade > Serviços instalados. Depois volte ao app.").setPositiveButton("Ativar",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("Voltar",null).show();}else open();});box.addView(direct);
  TextView note=new TextView(this);note.setText("Android 13+: se houver bloqueio, em Informações do app > menu ⋮, permita configurações restritas e volte aqui.\n\nA troca de IP depende da operadora. Nem todo aparelho oferece 3G ou 5G nessa tela.");note.setPadding(0,20,0,0);box.addView(note);setContentView(box);
 }
 void open(){
  if(launching||CycleService.live==null)return;launching=true;if(CycleService.live!=null)CycleService.live.reopen();
  String[][] components={{"com.android.phone","com.android.phone.settings.RadioInfo"},{"com.android.settings","com.android.settings.RadioInfo"},{"com.android.settings","com.android.settings.Settings$RadioInfoActivity"}};
  for(String[] c:components){try{Intent i=new Intent(Intent.ACTION_MAIN).setComponent(new ComponentName(c[0],c[1]));startActivity(i);finish();return;}catch(ActivityNotFoundException|SecurityException e){}}
  launching=false;
  new android.app.AlertDialog.Builder(this).setTitle("Tela indisponível neste aparelho").setMessage("O fabricante não permite abrir as informações do telefone por este atalho. Tente discar *#*#4636#*#* e abrir Informações do telefone. O painel aparece ao reconhecer essa tela.").setPositiveButton("OK",null).show();
 }
}
